let heading = document.getElementById("heading");
let name = "Ayesha Tayyaba";  
let regNo = "56546"; 
heading.innerHTML = heading.innerHTML + "- Name: " + name+ "- Reg No:" + regNo ;
