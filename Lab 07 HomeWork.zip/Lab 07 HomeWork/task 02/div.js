let divs = document.querySelectorAll(".Container");
        for (let i = 0; i < 3; i++) {
            divs[i].innerText ;
        }